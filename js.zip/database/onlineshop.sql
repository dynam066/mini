-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 23, 2019 at 07:53 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerece`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `getcat` (IN `cid` INT)  SELECT * FROM categories WHERE cat_id=cid$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_info`
--

CREATE TABLE `admin_info` (
  `admin_id` int(10) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `admin_email` varchar(300) NOT NULL,
  `admin_password` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_info`
--

INSERT INTO `admin_info` (`admin_id`, `admin_name`, `admin_email`, `admin_password`) VALUES
(1, 'admin', 'admin@gmail.com', '25f9e794323b453885f5181f1b624d0b');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `brand_id` int(100) NOT NULL,
  `brand_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`) VALUES
(1, 'Louis Vuitton'),
(2, 'Gucci'),
(3, 'Versace'),
(4, 'Calvin Klein'),
(5, 'Champion'),
(6, 'All Top Brands');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `qty` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `p_id`, `ip_add`, `user_id`, `qty`) VALUES
(6, 26, '::1', 4, 1),
(9, 10, '::1', 7, 1),
(10, 11, '::1', 7, 1),
(11, 45, '::1', 7, 1),
(44, 5, '::1', 3, 0),
(46, 2, '::1', 3, 0),
(48, 72, '::1', 3, 0),
(49, 60, '::1', 8, 1),
(50, 61, '::1', 8, 1),
(51, 1, '::1', 8, 1),
(52, 5, '::1', 9, 1),
(53, 2, '::1', 14, 1),
(54, 3, '::1', 14, 1),
(55, 5, '::1', 14, 1),
(56, 1, '::1', 9, 1),
(57, 2, '::1', 9, 1),
(71, 61, '127.0.0.1', -1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(100) NOT NULL,
  `cat_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(1, 'Shirts'),
(2, 'T-Shirts'),
(3, 'Kurtas'),
(4, 'Trousers'),
(5, 'Jeans'),
(6, 'Hoodies'),
(7, 'Jackets'),
(8, 'Dhoti'),
(9, 'Shorts'),
(10, 'Suits '),
(11, 'Coats &<br> Bathrobes'),
(12, 'Sweaters'),
(13, 'InnerWear');



-- --------------------------------------------------------

--
-- Table structure for table `email_info`
--

CREATE TABLE `email_info` (
  `email_id` int(100) NOT NULL,
  `email` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `email_info`
--

INSERT INTO `email_info` (`email_id`, `email`) VALUES
(3, 'admin@gmail.com'),
(4, 'felbinjo@gmail.com'),
(5, 'binilv@gmail.com'),
(6, 'asishjy@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `action` varchar(50) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(12) NOT NULL,
  `qty` int(11) NOT NULL,
  `trx_id` varchar(255) NOT NULL,
  `p_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `product_id`, `qty`, `trx_id`, `p_status`) VALUES
(1, 12, 7, 1, '07M47684BS5725041', 'Completed'),
(2, 14, 2, 1, '07M47684BS5725041', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `orders_info`
--

CREATE TABLE `orders_info` (
  `order_id` int(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `f_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` int(10) NOT NULL,
  `cardname` varchar(255) NOT NULL,
  `cardnumber` varchar(20) NOT NULL,
  `expdate` varchar(255) NOT NULL,
  `prod_count` int(15) DEFAULT NULL,
  `total_amt` int(15) DEFAULT NULL,
  `cvv` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders_info`
--

INSERT INTO `orders_info` (`order_id`, `user_id`, `f_name`, `email`, `address`, `city`, `state`, `zip`, `cardname`, `cardnumber`, `expdate`, `prod_count`, `total_amt`, `cvv`) VALUES
(1, 12, 'binil', 'binilv@gmail.com', '4515 Pointe Lane', 'HollyWood' , 'Florida', 33020, 'bvthz', '4321 2345 6788 7654', '12/90', 3, 77000, 1234);

-- --------------------------------------------------------

--
-- Table structure for table `order_products`
--

CREATE TABLE `order_products` (
  `order_pro_id` int(10) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(15) DEFAULT NULL,
  `amt` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_products`
--

INSERT INTO `order_products` (`order_pro_id`, `order_id`, `product_id`, `qty`, `amt`) VALUES
(73, 1, 1, 1, 5000),
(74, 1, 4, 2, 64000),
(75, 1, 8, 1, 40000);

-- ---------------------------------------------------------

-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(100) NOT NULL,
  `product_cat` int(100) NOT NULL,
  `product_brand` int(100) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_price` int(100) NOT NULL,
  `product_desc` text NOT NULL,
  `product_image` text NOT NULL,
  `product_keywords` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_cat`, `product_brand`, `product_title`, `product_price`, `product_desc`, `product_image`, `product_keywords`) VALUES

(1, 1, 6, 'PARADA Double Match Poplin Shirt', 5000, 'Double Match Poplin Shirt', 'vb.png', 'PARADA-Shirt'),
(2, 1, 1, 'LV Multicolor Watercolor Shirt', 4000, 'Multicolor Watercolor Shirt', 'bv.png', 'Louis Vuitton(LV)-Shirt'),
(3, 1, 1, 'LV DNA Shirt', 6000, 'DNA shirt', 'bb.png', 'Louis Vuitton(LV)-DNA shirt'),
(4, 1, 2, 'Gucci Nylon Shirt', 4000, 'Nylon Shirt', 'nylon-shirt.jpg', 'Light-Nylon Shirt'),
(5, 1, 6, 'Metallic Golden Shimmering Two Tone Long Sleeve Club Shirt', 3000, 'Golden Shirt', 'aa.jpg', 'Casual Shirt'),
(6, 1, 2, 'Gucci GG Harness Bowling shirt', 2500, 'GG Harness Bowling shirt', 's.png', 'Harness Bowling shirt'),
(7, 1, 2, 'Gucci Floral print Silk foulard Shirt', 3400, 'Floral print Silk foulard Shirt', 'a.jpg', 'Floral print Silk foulard Shirt'),
(8, 1, 2, 'Gucci Logo Embellished Bowling shirt', 2999, 'Embellished Bowling shirt in White', 'b.png', 'Embellished Bowling shirt'),
(9, 1, 2, 'Gucci Gg Psychedelic Print Bowling shirt', 3800, 'Psychedelic Print Bowling shirt', 'c.png', 'Psychedelic Print Bowling shirt'),
(10, 1, 3, 'Versace Barocco Mosaic-print silk shirt', 9900, 'Barocco Mosaic-print silk shirt', 'unnad.jpg', 'Barocco Mosaic-print silk shirt'),
(11, 1, 3, 'Versace Leopard-pattern beaded Shirt', 9000, 'Leopard-pattern beaded Shirt', 'd.png', 'Leopard-pattern Shirt'),
(12, 1, 3, 'versace Medusa Renaissance print Shirt', 8000, 'Medusa Renaissance print Shirt', 'versace.png', 'Medusa Renaissance print Shirt'),
(13, 1, 4, 'CK stylish party wear Shirt', 2500, 'ck party wear shirt', 'e.jpg', 'party wear shirt'),
(14, 1, 4, 'CK red white combination shirt', 2300, 'ck shirts', 'f.png', 'ck shirt'),
(15, 1, 4, 'CK cotton-men-printed Multicolor Shirt', 2500, 'ck Multicolor shirt', 'g.jpg', 'ck cotton shirt'),
(16, 1, 6, 'MSGM Trees print short sleeve Shirt', 3000, 'grafity printed shirt', 'h.png', 'MSGM shirt'),

(17, 2, 6, 'Billionaire Black-Graphic-Printed-Polo T-Shirt', 1000, 'Black-Graphic-Printed-Polo', 'i.jpg', 'Black-Graphic-Printed-Polo'),
(18, 2, 3, 'versace Henley-Neck and V-Neck-T Shirts', 800, 'Henley-Neck-and-V-Neck-Versace-T Shirts', 'j.jpg', 'Versace-T Shirts'),
(19, 2, 1, 'LV white printed T-Shirt', 500, 'T-Shirt', 'k.jpg', 'white T-Shirt'),
(20, 2, 2, 'Gucci bee printed T-Shirt with logo', 900, 'Gucci-Designer-T-Shirt', 'l.jpg', 'bee printed T-Shirt'),
(21, 2, 2, 'Gucci oversized cotton red T-Shirt', 750, 'Gucci T-Shirt', 'm.jpg', 'red T-Shirt'),
(22, 2, 2, 'Gucci oversized cotton silk T-Shirt with logo', 1500, 'cotton T-shirts', 'n.jpg', 'cotton T-Shirt with logo'),
(23, 2, 6, 'Being-Human Round-Half-Sleeves-T-Shirt', 820, 'Being-Human-Round-Half-Sleeves-T-Shirt', 'o.jpg', 'Being-Human-Round-Half-Sleeves-T-Shirt'),
(24, 2, 6, 'Armani logo-white T-Shirts', 590, 'T-shirts', 'p.jpg', 'T-shirts'),
(25, 2, 3, 'versace Baroccoflage stretch-cotton T-shirt', 800, 'versace Baroccoflage stretch-cotton T-shirt', 'q.jpg', 'versace T-shirt'),
(26, 2, 5, 'Champion Heritage All Over Print T-Shirt', 699, 'Heritage All Over Print T-Shirt', 'r.jpg', 'Heritage All Over Print T-Shirt'),
(27, 2, 5, 'Champion Over Script T-Shirt', 580, 'Over Script T-Shirt', 't.jpg', 'Over Script T-Shirt'),

(28, 3, 6, 'Route-by-pantaloons-men-beige-woven-design-straight-kurta', 3000, 'route-by-pantaloons-kurta', 'v.jpg', 'indus-route-by-pantaloons-kurta'),
(29, 3, 6, 'fabindia blue-cotton-dobby-slim-fit-long-kurta', 2860, 'fabindia--kurta', 'w.jpg', 'blue-cotton-dobby-slim-fit-long-kurta'),
(30, 3, 6, 'peter-england-Men-Navy-Kurta-Pyjama-And-Waistcoat', 4444, 'peter-england-Men-Navy-Kurta', 'x.jpg', 'peter-england-Men-Navy-Kurta'),
(31, 3, 6, 'Freehand-Mens-Cotton-Kurta-Pyjama', 2200, 'Freehand-Mens-Cotton-Kurta-Pyjama', 'y.jpg', 'Freehand-Mens-Cotton-Kurta-Pyjama'),
(32, 3, 6, 'Manyavar-Printed-Side-Button-Kurta', 1500, 'Manyavar-Printed-Side-Button-Kurta', 'z.jpg', 'Manyavar-Printed-Side-Button-Kurta'),

(33, 4, 3, 'Versace Jeans Couture jogging trousers with baroque print', 1100, 'Versace jogging trousers', 'a1.jpg', 'Versace jogging trousers'),
(34, 4, 3, 'versace Printed cotton sweatpants', 999, 'versace Printed cotton sweatpants', 'a2.jpg', 'versace cotton sweatpants'),
(35, 4, 3, 'versace LOGO EMBROIDERY COTTON SWEATPANTS', 899, 'versace COTTON SWEATPANTS', 'a3.jpg', 'versace SWEATPANTS'),
(36, 4, 5, 'Champion-sports-trousers', 600, 'Champion-sports-trousers', 'a4.jpg', 'Champion-sports-trousers'),
(37, 4, 2, 'Gucci TARTAN CHECK WOOL PANTS', 550, 'gucci TARTAN CHECK WOOL PANTS', 'a5.png', 'gucci TARTAN CHECK WOOL PANTS'),
(38, 4, 1, 'Louis Vuitton  Pinstripe straight leg trousers', 700, 'Louis Vuitton trousers', 'b1.png', 'Louis Vuitton trousers'),
(39, 4, 1, 'Louis Vuitton  Travertine classic pants', 400, 'Louis Vuitton classic pants', 'b2.png', 'Louis Vuitton classic pants'),
(40, 4, 4, 'ck Men Black Printed Track Pants', 600, 'ck Pants', 'b3.jpg', 'ck Men Black Printed Track Pants'),
(41, 4, 6, 'Gucci jogging pants', 700, 'Jogging Gucci', 'Jogging Gucci.jpg', 'Jogging Gucci'),
(42, 4, 4, 'CK White Brand Logo Printed Joggers', 900, 'Men White Brand Logo Printed Joggers', 'a11.jpg', 'Men White Brand Logo Printed Joggers'),
(43, 4, 6, 'Flash ski bib trousers', 680, 'Flash ski bib trousers', 'a6.jpg', 'Flash ski bib trousers'),

(44, 5, 3, 'Versace tie-dye straight-leg jeans', 1500, 'tie-dye straight-leg jeans', 'c1.jpg', 'tie-dye straight-leg jeans'),
(45, 5, 1, 'LV jeans', 1800, 'LV jeans', 'unnamed.jpg', 'LV jeans'),
(46, 5, 3, 'versace black solid jeans', 300, 'versace blsck solid jeans', 'v1.jpg', 'versace blsck solid jeans'),
(47, 5, 1, 'LV straight-fit-jeans', 1599, 'LV jeans', 'aa1.jpg', 'LV jeans'),
(48, 5, 1, 'louis-vuitton-salt-print-denim-jeans', 1999, 'louis-vuitton-salt-print-denim-pants', 'x1.jpg', 'louis-vuitton-salt-print-denim-pants'),
(49, 5, 4, 'ck slim fit', 1200, 'ck slim fit', 'c2.jpg', 'ck slim fit'),
(50, 5, 2, 'GUCCI 5 POCKET CORD JEANs', 1100, 'GUCCI 5 POCKET CORD JEAN', 'g1.jpg', 'GUCCI 5 POCKET CORD JEANS'),

(51, 6, 3, 'Medusa Amplified Print Hoodie-versace', 1800, 'MedusaAmplifiedPrintHoodie-Sweatshirts', 'a1.1.jpg', 'MedusaAmplifiedPrintHoodie'),
(52, 6, 3, 'versace -script-white Hoodie', 1800, 'Hoodie', 'xx.jpg', 'Hoodie'),
(53, 6, 6, 'Playboy-white -printed Hoodie', 1500, 'playboy', 'zzz.jpg', 'playboy Hoodies'),
(54, 6, 6, 'Batman logo printed cotton Hoodie', 1999, 'Hoodie', 'thz.jpg', 'Hoodie'),
(55, 6, 2, 'Gucci red Printed Hoodie', 1700, 'Hoodie', 'd1.jpg', 'Hoodie'),
(56, 6, 1, 'louis-vuitton-hoodie-with-bead-shark', 2100, 'louis-vuitton-hoodie-with-bead-shark', 'l1.jpg', 'louis-vuitton-hoodie-with-bead-shark'),
(57, 6, 1, 'louis-vuitton-lv-planes-printed-hoodie', 1200, 'Hoodie', 'm1.jpg', 'louis-vuitton-lv-planes-printed-hoodie'),
(58, 6, 1, 'louis-vuitton-mix-nylon-needle-punch-zipped-hoodie', 1600, 'Hoodie', 'm2.jpg', 'louis-vuitton-mix-nylon-needle-punch-zipped-hoodie'),
(59, 6, 1, 'louis-vuitton-monogram-mink-fur-zipped-hoodie', 2200, 'Hoodie', 'h1.jpg', 'Hoodie'),

(60, 7, 1, 'louis-vuitton-napolitana-jacket', 4300, 'louis-vuitton-napolitana-jacket', 'e1.jpg', 'louis-vuitton-napolitana-jacket'),
(61, 7, 1, 'louis-vuitton-pont-neuf-evening-jacket', 2500, 'louis-vuitton-pont-neuf-evening-jacket', 'e2.png', 'louis-vuitton-pont-neuf-evening-jacket'),
(62, 7, 1, 'louis-vuitton-silver-finish-mink-fur', 2500, 'louis-vuitton-silver-finish-mink-fur', 'e3.jpg', 'louis-vuitton-silver-finish-mink-fur'),
(63, 7, 1, 'louis-vuitton-window-pane-jacket', 2600, 'louis-vuitton-window-pane-jacket', 'e4.jpg', 'louis-vuitton-window-pane-jacket'),
(64, 7, 1, 'louis-vuitton-damier-suit-jacket', 1800, 'louis-vuitton-damier-suit-jacket', 'f1.jpg', 'louis-vuitton-damier-suit-jacket'),
(65, 7, 1, 'louis-vuitton-double-face-monogram-cutaway-jacket', 2000, 'louis-vuitton-double-face-monogram-cutaway-jacket', 'f2.jpg', 'louis-vuitton jacket'),
(66, 7, 1, 'louis-vuitton-fox-fur-jacket', 1899, 'louis-vuitton-fox-fur-jacket', 'i1.jpg', 'louis-vuitton-fox-fur-jacket'),
(67, 7, 1, 'louis-vuitton-lv-hooded-leather-jacket', 1700, 'louis-vuitton-lv-hooded-leather-jacket', 'i2.jpg', 'louis-vuitton-lv-hooded-leather-jacket'),
(68, 7, 1, 'louis-vuitton-monogram-workwear-denim-jacket', 1300, 'louis-vuitton-monogram-workwear-denim-jacket', 'bb1.jpg', 'louis-vuitton-monogram-denim-jacket'),
(69, 7, 2, 'gucci GG striped wool-blazer-Jacket', 1899, 'gucci GG striped wool blazer', 'k1.jpg', 'gucci GG striped wool jacket'),

(70, 8, 6, 'Double Dhoti White with Gold Jari 2 1/2 Kaviyam', 700, 'Double Dhoti White with Gold Jari', 'n1.jpg', 'Double Dhoti white'),

(71, 6, 1, 'louis-vuitton-monogram-mineral-mink-fur-zipped-hoodie', 1999, 'Hoodie', 'product07.png', 'Hoodie'),
(72, 11, 1, 'louis-vuitton-monogram-shearling-coat', 3060, 'louis-vuitton-monogram-shearling-coat', 'product02.png', 'louis-vuitton-monogram-shearling-coat'),
(73, 7, 1, 'louis-vuitton--skim fit jacket', 2000, 'louis-vuitton--Men_Show', 'product05.png', 'louis-vuitton--Men_Show'),
(74, 4, 3, 'LOGO BAROQUE PRINT VELVET TRACKPANTS', 2900, 'Mens pant', 'product01.png', 'trackpants'),
(75, 10, 6, 'Men Burgundy Solid Vest & Pant Set', 3000, 'Men Burgundy Solid Vest & Pant Set', 'product03.png', 'Men Burgundy Solid Vest & Pant Set'),
(76, 10, 6, 'Men Black & Gold-Coloured Printed Single-Breasted 2-Piece Slim-Fit Bandhgala Suit', 6000, 'Men Black Suit', 'product04.png', 'Men Black & Gold-Coloured Printed Single-Breasted'),
(77, 11, 1, 'louis-vuitton-sb-multi-pockets-coat', 3100, 'louis-vuitton-sb-multi-pockets-coat', 'product06.png', 'louis-vuitton-sb-multi-pockets-coat'),
(78, 1, 6, 'Mufti Mustard Yellow Checks Full Sleeves Relaxed Shirt', 2579, 'Mufti Mustard Yellow Checks Full Sleeves Relaxed Shirt', 'product08.png', 'Mufti Mustard Yellow Checks Full Sleeves Relaxed Shirt'),
(79, 7, 1, 'louis-vuitton-monogram-pocket-shearling-blouson', 2000, 'louis-vuitton-monogram-pocket-shearling-blouson', 'product09.png', 'louis-vuitton-monogram-pocket-shearling-blouson'),
(80, 12, 1, 'louis-vuitton-louis-vuitton-2054-patchwork-mock-neck', 870, 'louis-vuitton-louis-vuitton-2054-patchwork-mock-neck', 'product10.png', 'louis-vuitton-louis-vuitton-2054-patchwork-mock-neck'),
(81, 12, 1, 'louis-vuitton-lvse-lv-embossed-turtle-neck', 800, 'louis-vuitton-lvse-lv-embossed-turtle', 'product11.png', 'louis-vuitton-lvse-lv-embossed-turtle-neck'),
(82, 13, 3, 'Versace LA GRECA PRINT BRIEFS', 550, 'LA GRECA PRINT BRIEFS', 'product12.png', 'LA GRECA PRINT BRIEFS'),
(83, 9, 3, 'versace swimshorts', 400, 'short', 'product13.png', 'shorts'),
(84, 2, 6, 'White polo T-shirt', 280, 'Tshirt', 'product14.png', 'tshirt'),
(85, 13, 3, 'Barocco Print Undershirt-Tanks-versace', 300, 'Undershirt', 'product15.png', 'BaroccoPrintUndershirt-Tanks-versace'),

(86, 8, 6, 'Mens Colour Dhoti with Gold Jari', 730, 'Mens Colour Dhoti with Gold Jari', 'n2.jpg', 'Mens Colour Dhoti with Gold Jari'),
(87, 8, 6, 'Mens Combo Set White Dhoti,Shirt Bit&Towel 1/2 Gold Jari Vaisant', 2000, 'Mens Combo Set', 'n3.jpg', 'Mens Combo Set'),
(88, 8, 6, 'Mens Cotton Lungi Rainbow', 500, 'Mens Cotton Lungi Rainbow', 'o1.jpg', 'Mens Cotton Lungi Rainbow'),
(89, 8, 6, 'Mens Double Dhoti with Fancy Border Panchami Fancy Blue', 800, 'Mens Double Dhoti with Fancy Blue', 'o2.jpg', 'Mens Double Dhoti with Fancy Blue'),
(90, 8, 6, 'Mens Panchakacham Dhoti with Angavasthram Navaratnam GY', 1130, 'Mens Panchakacham Dhoti', 'o3.jpg', 'Mens Panchakacham Dhoti'),
(91, 8, 6, 'Mens Ready Made Panchakacham Cream Prakaspati', 1000, 'Mens Ready Made Panchakacham Cream Prakaspati', 'o4.jpg', 'dhoti'),
(92, 8, 6, 'Mens Single Dhoti White with Silver Jari', 600, 'Mens Single Dhoti', 'o5.jpg', 'Mens Single Dhoti White with Silver Jari'),

(93, 9, 1, 'louis-vuitton-watercolor-swim-shorts', 850, 'louis-vuitton-watercolor-swim-short', 'bv1.jpg', 'louis-vuitton-watercolor-swim-short'),
(94, 9, 1, 'louis-vuitton-3d-pocket-monogram-board-shorts', 660, 'louis-vuitton-3d-pocket-monogram-board-shorts', 'ab.jpg', 'louis-vuitton shorts'),
(95, 9, 1, 'louis-vuitton-louis-vuitton-2054-packable-swimwear', 500, 'louis-vuitton-swimwear', 'ab1.jpg', 'louis-vuitton-louis-vuitton swimwear'),
(96, 9, 3, 'Logo-Swim-Shorts-Beachwear-versace-grey', 599, 'LogoSwimShorts-Beachwear-versace', 'j1.jpg', 'LogoSwimShorts-Beachwear-versace'),
(97, 9, 3, 'La Greca Print Swim Shorts-Beachwear-versace', 399, 'LaGrecaPrintSwimShorts-Beachwear-versace', 'cx.jpg', 'LaGrecaPrintSwimShorts-Beachwear-versace'),
(98, 9, 3, 'Logo Long SwimShorts-Beachwear-versace', 400, 'LogoLongSwimShorts-Beachwear-versace', 'cx1.jpg', 'LogoLongSwimShorts-Beachwear-versace'),
(99, 9, 4, 'ck Men Yellow Brand logo Printed Applique Pure Cotton Regular Shorts', 500, 'ck Men Yellow Shorts', 'ck.jpg', 'ck Men Yellow Shorts'),
(100, 9, 6, 'asics Fujitrail track shorts', 450, 'asics Fujitrail track shorts', 'cz.jpg', 'asics Fujitrail track shorts'),

(101, 10, 6, 'VanHeusen-Men Blue & Grey Checked Slim-Fit Single-Breasted 3-Piece Formal Suit', 3000, 'VanHeusen-Men Suit', 'zzz (2).jpg', 'VanHeusen-Men Suit'),
(102, 10, 6, 'lp Men Grey Striped Slim Fit Single Breasted Formal Suit', 3900, 'lp Men Suit', 'nn.jpg', 'lp Men Suit'),
(103, 10, 1, 'peter england Men Navy Three Piece Suit', 4400, 'peter england Men Navy Three Piece Suit', 'ppt.jpg', 'peter england Men Navy Three Piece Suit'),
(104, 10, 6, 'blackberry Men Grey & Navy Blue Checked Slim Fit Single-Breasted Partywear 3-Piece Suit', 3700, 'blackberry Men Suit', 'mnb.jpg', 'blackberry Suit'),
(105, 10, 2, 'gucci embroidered GG suit', 3800, 'gucci embroidered GG suit', 'gucci embroidered GG suit.jpg', 'gucci embroidered GG suit'),
(106, 10, 2, 'gucci slim-fit two-piece suit', 2600, 'gucci slim-fit two-piece suit', 'gucci slim-fit two-piece suit.jpg', 'gucci slim-fit two-piece suit'),

(107, 11, 3, 'IBaroqueBathrobe-Bathrobes-versace', 3100, 'IBaroqueBathrobe-Bathrobes-versace', '999.jpg', 'IBaroqueBathrobe-Bathrobes-versace'),
(108, 11, 3, 'IBaroque-Bathrobes-versace', 3099, 'IBaroqueBathrobe-Bathrobes-versace', '9.jpg', 'IBaroqueBathrobe-Bathrobes-versace'),
(109, 11, 3, 'Virtus Dressing Gown-Bathrobes-versace', 2999, 'VirtusDressingGown-Bathrobes-versace', '99.jpg', 'VirtusDressingGown-Bathrobes-versace'),
(110, 11, 3, 'LaCoupe-DesDieux Print Bathrobe-Bathrobes-versace', 3800, 'LaCoupeDesDieuxPrintBathrobe-Bathrobes-versace', '8.jpg', 'LaCoupeDesDieuxPrintBathrobe'),
(111, 11, 3, 'IBaroquePrintBathrobe-Bathrobes-versace', 3100, 'IBaroquePrintBathrobe-Bathrobes-versace', '88.jpg', 'IBaroquePrintBathrobe-Bathrobes-versace'),
(112, 11, 3, 'gucci SINGLE BREAST WOOL BLEND COAT', 2500, 'gucci SINGLE BREAST WOOL BLEND COAT', '7.jpg', 'gucci SINGLE BREAST WOOL BLEND COAT'),
(113, 11, 3, 'gucci-blue-Logo-jacquard-Wool-blend-Coat', 2300, 'gucci-blue-Logo-jacquard-Wool-blend-Coat', '77.jpeg', 'gucci-blue-Logo-jacquard-Wool-blend-Coat'),
(114, 11, 1, 'louis-vuitton-double-breasted-tailored-coat', 2200, 'louis-vuitton-double-breasted-tailored-coat', '6.jpg', 'louis-vuitton-double-breasted-tailored-coat'),
(115, 11, 1, 'louis-vuitton-tartan-check-extra-large-coat', 2899, 'louis-vuitton-tartan-check-extra-large-coat', '5.png', 'louis-vuitton-tartan-check-extra-large-coat'),
(116, 11, 1, 'louis-vuitton-wrap-coat', 2300, 'louis-vuitton-wrap-coat', '62.jpg', 'louis-vuitton-wrap-coat'),

(117, 12, 1, 'louis-vuitton-monogram-jacquard-sweatshirt', 1000, 'louis-vuitton-monogram-jacquard-sweatshirt', 'lv1.jpg', 'louis-vuitton-monogram-jacquard-sweatshirt'),
(118, 12, 1, 'louis-vuitton-monogram-shearling-crewneck', 999, 'louis-vuitton-monogram-shearling-crewneck', 'lv2.jpg', 'louis-vuitton-monogram-shearling-crewneck'),
(119, 12, 1, 'louis-vuitton-two-tone-high-neck-with-half-zip', 1020, 'louis-vuitton-two-tone-high-neck-with-half-zip', 'lv3.jpg', 'louis-vuitton-two-tone-high-neck-with-half-zip'),
(120, 12, 1, 'louis-vuitton-basket-weave-knitted-crewneck', 800, 'louis-vuitton-basket-weave-knitted-crewneck', 'lv4.png', 'louis-vuitton-basket-weave-knitted-crewneck'),
(121, 12, 1, 'louis-vuitton-corduroy-shearling-cardigan', 980, 'louis-vuitton-corduroy-shearling-cardigan', 'lv5.jpg', 'louis-vuitton-corduroy-shearling-cardigan'),
(122, 12, 1, 'louis-vuitton-louis-vuitton-2054-multi-logos-crewneck', 1040, 'louis-vuitton-crewneck', 'lv6.jpg', 'louis-vuitton-louis-vuitton-2054-multi-logos-crewneck'),
(123, 12, 1, 'louis-vuitton-mink-fur-sweater', 950, 'louis-vuitton-mink-fur-sweater', 'lv7.jpg', 'louis-vuitton-mink-fur-sweater'),
(124, 12, 1, 'louis-vuitton-monogram-fur-crewneck', 840, 'louis-vuitton-monogram-fur-crewneck', 'lv8.jpg', 'louis-vuitton-monogram-fur-crewneck'),
(125, 12, 3, 'versace LOGO PRINT SWEATSHIRT', 799, 'LOGO PRINT SWEATSHIRT', 'LOGO PRINT SWEATSHIRT.jpg', 'LOGO PRINT SWEATSHIRT'),

(126, 13, 3, 'Versace-BAROCCO PRINT TRUNKS', 600, 'BAROCCO PRINT TRUNKS', 'BAROCCO PRINT TRUNKS.jpg', 'BAROCCO PRINT TRUNKs'),
(127, 13, 3, 'Versace-BAROCCO PRINT LOW RISE BRIEFS', 500, 'BAROCCO PRINT LOW RISE BRIEFS', 'BAROCCO PRINT LOW RISE BRIEFS.jpg', 'BAROCCO PRINT LOW RISE BRIEFS'),
(128, 13, 2, 'premium_mens_gucci_boxer', 399, 'premium_mens_gucci_boxer', 'premium_mens_gucci_boxer_under_1592293505_26dae3f1_progressive.jpg', 'premium_mens_gucci_boxer'),
(129, 13, 5, 'champion red logo print', 330, 'boxer', '79684.jpg', 'boxer'),
(130, 13, 1, 'louis-vuitton-logo print boxer', 380, 'boxer', 'cc6159a08e5d9b04d5fe9d77cf1aa726.jpg', 'boxer'),
(131, 13, 3, 'Under shirt Bi-Pack-Tanks-versace', 300, 'Undershirt', '90_AU10193-A232741_A1001_10_UndershirtBi-Pack-Tanks-versace-online-store_0_2.jpg', 'UndershirtBi-Pack-Tanks-versace'),
(132, 13, 5, 'champion Undershirt', 310, 'boxer', '8131607_default_1.jpg', 'boxer');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
(12, 'binil', 'vincent', 'binilvincent00@gmail.com', 'bvthz00', '+1 7902554500', '4522 Confederate Drive', 'Hartsdale, NY'),
(15, 'felbin', 'john', 'felbinjohn00@gmail.com', 'fjnyc00', '+1 9645675900', '1330 Hinkle Deegan Lake Road', 'Liverpool, NY'),
(16, 'asish', 'jolly', 'asishjolly00@gmail.com', 'ajbts00', '+1 9847136700', '2400 Geneva Street', 'NY, NY');


--
-- Triggers `user_info`
--
DELIMITER $$
CREATE TRIGGER `after_user_info_insert` AFTER INSERT ON `user_info` FOR EACH ROW BEGIN 
INSERT INTO user_info_backup VALUES(new.user_id,new.first_name,new.last_name,new.email,new.password,new.mobile,new.address1,new.address2);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user_info_backup`
--

CREATE TABLE `user_info_backup` (
  `user_id` int(10) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info_backup`
--

INSERT INTO `user_info_backup` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
(12, 'binil', 'vincent', 'binilvincent00@gmail.com', 'bvthz00', '+1 7902554500', '4522 Confederate Drive', 'Hartsdale, NewYork'),
(15, 'felbin', 'john', 'felbinjohn00@gmail.com', 'fjnyc00', '+1 9645675900', '1330 Hinkle Deegan Lake Road', 'Liverpool, NewYork'),
(16, 'asish', 'jolly', 'asishjolly00@gmail.com', 'ajbts00', '+1 9847136700', '2400 Geneva Street', 'NewYork, NewYork');


--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_info`
--
ALTER TABLE `admin_info`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `email_info`
--
ALTER TABLE `email_info`
  ADD PRIMARY KEY (`email_id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `orders_info`
--
ALTER TABLE `orders_info`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_products`
--
ALTER TABLE `order_products`
  ADD PRIMARY KEY (`order_pro_id`),
  ADD KEY `order_products` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_info_backup`
--
ALTER TABLE `user_info_backup`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_info`
--
ALTER TABLE `admin_info`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `brand_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `email_info`
--
ALTER TABLE `email_info`
  MODIFY `email_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orders_info`
--
ALTER TABLE `orders_info`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `order_products`
--
ALTER TABLE `order_products`
  MODIFY `order_pro_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `user_info_backup`
--
ALTER TABLE `user_info_backup`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders_info`
--
ALTER TABLE `orders_info`
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`);

--
-- Constraints for table `order_products`
--
ALTER TABLE `order_products`
  ADD CONSTRAINT `order_products` FOREIGN KEY (`order_id`) REFERENCES `orders_info` (`order_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
